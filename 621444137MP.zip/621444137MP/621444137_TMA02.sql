# Delete the Suwapiyasa database and all its contents if they are already exists.
DROP DATABASE IF EXISTS Suwapiyasa_db;

# Create the Suwapiyasa database
CREATE DATABASE Suwapiyasa_db;

# Switch to using the Suwapiyasa database
USE Suwapiyasa_db;

# Create the Staff table
CREATE TABLE Staff (
    empId INT PRIMARY KEY,
    emp_name VARCHAR(100) NOT NULL,
    gender VARCHAR(10) NOT NULL,
    address VARCHAR(200) NOT NULL,
    telephone_number VARCHAR(15) NOT NULL
);
# Create the Doctor table
CREATE TABLE Doctor (
    empId INT PRIMARY KEY,
    specialty VARCHAR(100) NOT NULL,
    hdNo INT,
    FOREIGN KEY (empId) REFERENCES Staff (empId)
);
# Create the Nurse table
CREATE TABLE Nurse (
    empId INT PRIMARY KEY,
    grade INT NOT NULL,
    years_of_experience INT NOT NULL,
    surgery_skill_type VARCHAR(100),
    salary decimal(10, 2) NOT NULL,
    FOREIGN KEY (empId) REFERENCES Staff (empId)
);

# Create the Surgeon table
CREATE TABLE Surgeon (
    empId INT PRIMARY KEY,
    specialty VARCHAR(100) NOT NULL,
    type_of_contract VARCHAR(50) NOT NULL,
    length_of_contract INT NOT NULL
);

# Create the Location table
CREATE TABLE Location (
    bed_No INT NOT NULL,
    room_No int NOT NULL UNIQUE PRIMARY KEY,
    nursing_unit VARCHAR(50) NOT NULL
    );
-- Create the Medication table
CREATE TABLE Medication (
    med_code INT NOT NULL UNIQUE PRIMARY KEY,
    med_name VARCHAR(100) NOT NULL,
    quantity_on_hand INT NOT NULL,
    quantity_ordered INT NOT NULL,
    cost DECIMAL(10, 2) NOT NULL,
    exp_Date DATE NOT NULL
);
# Create the Patient table
CREATE TABLE Patient (
    pId INT PRIMARY KEY,
	initial varchar(5),
	surname varchar(50),
    age INT NOT NULL,
    address VARCHAR(200) NOT NULL,
    tele_No VARCHAR(15) NOT NULL,
    blood_type VARCHAR(5),
    allergy VARCHAR(200),
    room_No int NOT NULL,
    med_code INT NOT NULL,
	FOREIGN KEY (room_No) REFERENCES Location(room_No),
	FOREIGN KEY (med_code) REFERENCES Medication(med_code)
);
# Create the Surgery table
CREATE TABLE Surgery (
    pId INT NOT NULL,
    surgery_name VARCHAR(100) NOT NULL UNIQUE,
    date DATE NOT NULL,
    time TIME NOT NULL,
    category VARCHAR(50) NOT NULL,
    special_need VARCHAR(200),
    surgeon_empId INT NOT NULL,
    theater VARCHAR(50) NOT NULL,
    FOREIGN KEY (pId) REFERENCES Patient (pId),
    FOREIGN KEY (surgeon_empId) REFERENCES Surgeon (empId)
);
# Insert the data into the Staff table
INSERT INTO Staff (empId, emp_name , gender, address, telephone_number)
VALUES
    (1, 'Renuka Peiris', 'Male', '123 Main St Gampaha', '0775641238'),
    (2, 'Janani Fernando', 'Female', '456 flower Rd Colombo5', '0701452369'),
    (3, 'Melan Gunathilaka', 'Male', '789 Havelock Rd Colombo5', '0765489231'),
    (4, 'Shriyani Perera', 'Female', '987 Temple St Peliyagoda', '07788899990');
SELECT * FROM Staff;
    
# Insert the data into the Doctor table
INSERT INTO Doctor (empId, specialty, hdNo)
VALUES
    (1, 'Cardiology', NULL),
    (2, 'Orthopedics', 1),
    (3, 'Pediatrics', 1),
    (4, 'Neurology', NULL);
SELECT * FROM Doctor;

# Insert the data into the Nurse table
INSERT INTO Nurse (empId, grade, years_of_experience, surgery_skill_type,salary)
VALUES
    (1, 1, 5, 'General',35000),
    (2, 2, 8, 'Orthopedics',40000),
    (3, 2, 6, 'Cardiology',50000),
    (4, 3, 10, 'Neurology',45000);
SELECT * FROM Nurse;
    
 # Insert the data into the Surgeon table   
INSERT INTO Surgeon (empId, specialty, type_of_contract, length_of_contract)
VALUES
    (5, 'General Surgery', 'Contractor', 2),
    (6, 'Cardiac Surgery', 'Contractor', 1),
    (7, 'Neurological Surgery', 'Contractor', 3);
SELECT * FROM Surgeon;

# Insert the data into the Location table
INSERT INTO Location (bed_No, room_No, nursing_unit)
VALUES
    (101, 1, 'Cardiology'),
    (102, 2, 'Orthopedics'),
    (201, 3, 'Pediatrics'),
    (202, 4, 'Neurology');
 SELECT * FROM Location;
 
# Insert the data into the Medication table    
INSERT INTO Medication (med_code, med_name, quantity_on_hand, quantity_ordered, cost, exp_Date)
VALUES
    (2001, 'Aspirin', 100, 50, 10.99, '2028-06-30'),
    (2002, 'Ibuprofen', 200, 100, 7.50, '2025-12-15'),
    (2003, 'Acetaminophen', 150, 75, 8.25, '2026-09-22');
 SELECT * FROM Medication;
 
# Insert the data into the Patient table    
INSERT INTO Patient (pId, initial, surname, age, address, tele_No, blood_type, allergy,room_No,med_code)
VALUES
    (1001, 'M', 'De Silva', 65, '456 Temple Rd Colombo02', '0715556842', 'A+', Null,'1',2001),
    (1002, 'R D','Wickramage',  30, '76 Negombo Rd Colombbo1', '0777125033', 'O-', 'Penicillin','2',2002),
    (1003, 'L D', 'Peiris',25, '321 Perera Ln Colombo7', '0787776666', 'AB+', NULL,'3',2003),
    (1004, 'W', 'Perera', 38, '654 Maple StColombo4', '0710888777', 'B+', 'Pollen','4',2001);
SELECT * FROM Patient;
    
# Insert the data into the Surgery table    
INSERT INTO Surgery (pId, surgery_name, date, time, category, special_need, surgeon_empId, theater)
VALUES
    (1001, 'Appendectomy', '2023-07-20', '10:00:00', 'General', NULL, 5, 'Theater A'),
    (1002, 'Knee Replacement', '2023-08-05', '14:30:00', 'Orthopedic', NULL, 6, 'Theater B');
SELECT * FROM Surgery;