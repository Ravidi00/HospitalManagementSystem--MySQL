USE Suwapiyasa_db;
# Q1 - 621444137
CREATE VIEW PatientSurgeryView AS
SELECT
    p.pId AS 'Patient ID',
    CONCAT(p.initial, ' ', p.surname) AS 'Patient Name',
    CONCAT(l.bed_No, '/', l.room_No) AS 'Location',
    s.surgery_name AS 'Surgery Name',
    s.date AS 'Surgery Date'
FROM
    Patient p
INNER JOIN
    Surgery s ON p.pId = s.pId
INNER JOIN
    Location l ON p.room_No = l.room_No;
SELECT * FROM PatientSurgeryView;

# Q2 - 621444137
-- Create the MedInfo table
CREATE TABLE MedInfo (
    MedName varchar(50) NOT NULL PRIMARY KEY,
    QuantityAvailable int NOT NULL,
    ExpirationDate date NOT NULL
);

SELECT * FROM MedInfo;
# Q2(i) - 621444137
DELIMITER //
CREATE TRIGGER InsertMedicationTrigger
AFTER INSERT ON Medication
FOR EACH ROW
BEGIN
    INSERT INTO MedInfo (MedName, QuantityAvailable, ExpirationDate)
    VALUES (NEW.med_name, NEW.quantity_on_hand, NEW.exp_Date);
END;
//
DELIMITER ;

# Q2(ii) - 621444137
DELIMITER //
CREATE TRIGGER UpdateMedicationTrigger
AFTER UPDATE ON Medication
FOR EACH ROW
BEGIN
    UPDATE MedInfo
    SET QuantityAvailable = NEW.quantity_on_hand, ExpirationDate = NEW.exp_Date
    WHERE MedName = NEW.med_name;
END;
//
DELIMITER ;
INSERT INTO Medication (med_code, med_name, quantity_on_hand, quantity_ordered, cost, exp_Date)
VALUES
    (2004, 'Allermine', 100, 50, 5.00, '2029-06-30'),
    (2005, 'Amoxiline', 100, 100, 10.50, '2027-12-18');
SELECT * FROM MedInfo;

# Q2(iii) - 621444137 
DELIMITER //
CREATE TRIGGER DeleteMedInfo
AFTER DELETE ON Medication
FOR EACH ROW
BEGIN
    DELETE FROM MedInfo WHERE MedName = OLD.med_name;
END;
//
DELIMITER ;
DELETE FROM Medication WHERE med_code = '2005';

# Q3 - 621444137

-- Define a stored procedure to calculate the number of medications taken by a patient.
DELIMITER //
CREATE PROCEDURE GetMedicationsTaken(
    IN PatientID INT,
    INOUT MedicationCount INT
)
BEGIN
    SELECT COUNT(*) INTO MedicationCount
    FROM Medication
    WHERE PatientID = PatientID;
END;
//
DELIMITER ;

-- Set a session variable 'patientID','MedicationCount' with an example patient ID
SET @patientID = 1001;
SET @MedicationCount = 100;
--  to calculate the medication count for the patient.
CALL GetMedicationsTaken(@PatientID, @MedicationCount);

-- Retrieve and display the calculated number of medications saved in the 'noOfMedications' variable
SELECT @MedicationCount AS 'Medications Taken';

# Q4 - 621444137
-- To calculate the number of days until medication expiration.
DELIMITER //
CREATE FUNCTION NoOfDaysUntilExpiration(exp_Date DATE)
RETURNS INT
DETERMINISTIC
BEGIN
    RETURN DATEDIFF(exp_Date, CURDATE());
END;
//
DELIMITER ;
-- To find medications with less than 30 days remaining for expiry
SELECT * FROM Medication
WHERE NoOfDaysUntilExpiration(exp_Date) <= 30;

# Q5 - 521444611
-- Retrieve all records from the Staff table after exporting data from Staff.xml file
SELECT * FROM Staff;
-- Retrieve all records from the Patient table after exporting data from Patient.xml file
SELECT * FROM Patient;


